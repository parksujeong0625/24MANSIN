# 🚀 24만신 Vercel 배포 가이드

## 📋 목차
1. [Vercel 계정 생성 & GitHub 연동](#1-vercel-계정-생성--github-연동)
2. [GitHub에 코드 업로드](#2-github에-코드-업로드)
3. [Vercel 프로젝트 생성](#3-vercel-프로젝트-생성)
4. [환경 변수 설정](#4-환경-변수-설정)
5. [광고 설정](#5-광고-설정)
6. [배포 확인](#6-배포-확인)
7. [자동 배포 설정](#7-자동-배포-설정)

---

## 1. Vercel 계정 생성 & GitHub 연동

### STEP 1: Vercel 가입
1. https://vercel.com 접속
2. **"Sign Up"** 클릭
3. **"Continue with GitHub"** 선택 (가장 간편!)
4. GitHub 계정으로 로그인
5. Vercel 권한 승인

✅ **완료!** 이제 GitHub과 Vercel이 연동되었습니다.

---

## 2. GitHub에 코드 업로드

### 파일 구조 확인
프로젝트 폴더에 다음 파일들이 있어야 합니다:

```
24만신/
├── index.html              ← 메인 HTML 파일
├── vercel.json            ← Vercel 설정 파일
├── api/
│   └── unsplash.js        ← 서버리스 함수 (Unsplash API)
├── manifest.json          ← PWA 설정 (있다면)
├── service-worker.js      ← Service Worker (있다면)
├── icon-192.png          ← 앱 아이콘 (있다면)
└── icon-512.png          ← 앱 아이콘 (있다면)
```

### STEP 2: GitHub 저장소 생성

**방법 A: GitHub 웹사이트에서 생성**
1. https://github.com 접속
2. 오른쪽 상단 **"+"** → **"New repository"**
3. Repository name: `24mansin` (또는 원하는 이름)
4. Public 선택 (무료 배포를 위해)
5. **"Create repository"** 클릭

**방법 B: 기존 저장소 사용**
- 이미 GitHub 저장소가 있다면 그대로 사용

### STEP 3: 코드 업로드

**터미널/명령 프롬프트에서:**

```bash
# 프로젝트 폴더로 이동
cd /path/to/24만신

# Git 초기화 (처음이라면)
git init

# 파일 추가
git add .

# 커밋
git commit -m "Vercel 배포를 위한 초기 설정"

# GitHub 저장소 연결 (본인의 저장소 URL로 변경)
git remote add origin https://github.com/본인계정/24mansin.git

# 업로드
git push -u origin main
```

**또는 GitHub Desktop 사용:**
1. GitHub Desktop 앱 실행
2. "Add an Existing Repository" 선택
3. 프로젝트 폴더 선택
4. "Publish repository" 클릭

---

## 3. Vercel 프로젝트 생성

### STEP 1: Vercel 대시보드
1. https://vercel.com/dashboard 접속
2. **"Add New..."** → **"Project"** 클릭

### STEP 2: GitHub 저장소 선택
1. GitHub 저장소 목록에서 `24mansin` 찾기
2. **"Import"** 클릭

### STEP 3: 프로젝트 설정
다음 설정을 확인하고 그대로 둡니다:

```
Framework Preset: Other
Root Directory: ./
Build Command: (비워둠)
Output Directory: (비워둠)
Install Command: (비워둠)
```

**아직 "Deploy" 누르지 마세요!** 먼저 환경 변수를 설정해야 합니다.

---

## 4. 환경 변수 설정

### STEP 1: Unsplash API 키 발급

1. https://unsplash.com/developers 접속
2. 로그인/가입
3. **"New Application"** 클릭
4. 약관 동의
5. 애플리케이션 정보 입력:
   ```
   Application name: 24만신
   Description: 사주 기반 이사운세 앱
   ```
6. **"Create application"** 클릭
7. **"Access Key"** 복사 (예: `abc123xyz...`)

### STEP 2: Vercel에 환경 변수 추가

Vercel 프로젝트 설정 페이지에서:

1. **"Environment Variables"** 섹션 찾기
2. 다음 정보 입력:
   ```
   Key: UNSPLASH_ACCESS_KEY
   Value: (위에서 복사한 Access Key 붙여넣기)
   ```
3. Environment: **Production, Preview, Development 모두 체크**
4. **"Add"** 클릭

✅ **환경 변수 설정 완료!**

---

## 5. 광고 설정

### STEP 1: Kakao Adfit 가입

1. https://adfit.kakao.com 접속
2. Kakao 계정으로 로그인
3. **"매체 등록"** 클릭
4. 정보 입력:
   ```
   매체명: 24만신
   URL: 나중에 Vercel에서 받은 URL 입력 (예: https://24mansin.vercel.app)
   카테고리: 엔터테인먼트 > 운세/사주
   ```

### STEP 2: 광고 단위 생성

**전면 광고 1개:**
- 광고 유형: **전면형 광고**
- 크기: 320x480
- 광고 단위 ID 복사 (예: `DAN-xxxxx`)

**배너 광고 2개:**
- 광고 유형: **배너 광고**
- 크기: 320x50
- 각각의 광고 단위 ID 복사

### STEP 3: index.html에 광고 ID 입력

GitHub에서 `index.html` 파일 수정:

```html
<!-- 전면 광고 -->
<ins class="kakao_ad_area" style="display:none;"
     data-ad-unit="DAN-xxxxx"  ← 본인의 전면광고 ID
     data-ad-width="320"
     data-ad-height="100"></ins>

<!-- 배너 광고 1 -->
<ins class="kakao_ad_area" style="display:none;"
     data-ad-unit="DAN-yyyyy"  ← 본인의 배너광고 ID 1
     data-ad-width="320"
     data-ad-height="50"></ins>

<!-- 배너 광고 2 -->
<ins class="kakao_ad_area" style="display:none;"
     data-ad-unit="DAN-zzzzz"  ← 본인의 배너광고 ID 2
     data-ad-width="320"
     data-ad-height="50"></ins>
```

수정 후 **Commit** 및 **Push**

---

## 6. 배포 확인

### STEP 1: Vercel 배포 시작

Vercel 프로젝트 설정 페이지에서:
1. 모든 설정 확인
2. **"Deploy"** 버튼 클릭
3. 배포 진행 상황 확인 (약 1-2분 소요)

### STEP 2: 배포 완료 확인

배포가 완료되면:
1. **"Visit"** 버튼 클릭
2. 앱이 정상 작동하는지 확인
3. URL 복사 (예: `https://24mansin.vercel.app`)

### STEP 3: 테스트

1. **양식 작성 → 제출**
2. **5초 전면 광고 표시 확인**
3. **결과 페이지에서 도시 이미지 표시 확인**
4. **배너 광고 2개 표시 확인**

---

## 7. 자동 배포 설정

✅ **이미 설정되어 있습니다!**

GitHub에 Push하면 자동으로 Vercel에 배포됩니다:

```bash
# 코드 수정
git add .
git commit -m "광고 ID 업데이트"
git push

# 자동으로 Vercel에 배포됨! (약 1분 소요)
```

---

## 🎯 완료 체크리스트

- [ ] Vercel 계정 생성 및 GitHub 연동
- [ ] GitHub에 코드 업로드
- [ ] Vercel 프로젝트 생성
- [ ] Unsplash API 키 발급 및 환경 변수 설정
- [ ] Kakao Adfit 가입 및 광고 단위 생성
- [ ] index.html에 광고 ID 입력
- [ ] Vercel 배포 완료
- [ ] 앱 작동 테스트 완료

---

## 🔧 추가 설정 (선택사항)

### 커스텀 도메인 연결

1. Vercel 프로젝트 → **"Settings"** → **"Domains"**
2. 본인 도메인 입력 (예: `24mansin.com`)
3. DNS 설정 안내에 따라 도메인 등록

### Analytics 활성화

1. Vercel 프로젝트 → **"Analytics"** 탭
2. **"Enable Analytics"** 클릭
3. 사용자 통계 실시간 확인 가능

### Kakao Adfit URL 업데이트

1. Adfit 대시보드 → **매체 관리**
2. URL을 Vercel URL로 업데이트
3. 승인 대기 (1-2일)

---

## 💡 유용한 팁

### 배포 로그 확인
- Vercel 대시보드 → 프로젝트 → **"Deployments"** 탭
- 배포 실패 시 로그에서 에러 확인

### 환경 변수 수정
- Vercel 대시보드 → 프로젝트 → **"Settings"** → **"Environment Variables"**
- 변수 수정 후 **"Redeploy"** 필요

### 배포 롤백
- Vercel 대시보드 → **"Deployments"** → 이전 배포 선택 → **"Promote to Production"**

---

## 🆘 문제 해결

### 도시 이미지가 안 나와요
1. Vercel 대시보드 → **Settings** → **Environment Variables**
2. `UNSPLASH_ACCESS_KEY` 확인
3. 값이 올바른지 확인
4. **Redeploy** 클릭

### 광고가 안 나와요
1. Kakao Adfit 승인 완료 확인 (1-2일 소요)
2. 광고 단위 ID가 정확한지 확인
3. 브라우저 콘솔(F12) 에러 확인

### 배포 실패
1. `vercel.json` 파일 존재 확인
2. `api/unsplash.js` 파일 존재 확인
3. Vercel 배포 로그 확인

---

## 🎉 완료!

이제 앱이 https://24mansin.vercel.app (본인 URL)에서 실행됩니다!

**다음 단계:**
1. SNS에 앱 공유
2. Analytics로 사용자 분석
3. 수익 확인 및 최적화

궁금한 점이 있으면 언제든 문의하세요! 😊
